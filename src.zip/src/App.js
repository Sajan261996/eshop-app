import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import AppBar from "./components/AppBar";
import Signup from "./components/Signup";
import Login from "./components/Login";
import Product from "./components/Product";
import ProductDetails from "./components/ProductDetails"; // Import ProductDetails
import axios from "axios";

const theme = createTheme({
  spacing: 8,
});

function App() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // Track data loading state

  useEffect(() => {
    const fetchData = async () => {
      try {
        const productResponse = await axios.get(
          "https://dev-project-ecommerce.upgrad.dev/api/products"
        );
        setProducts(productResponse.data);

        const categoryResponse = await axios.get(
          "https://dev-project-ecommerce.upgrad.dev/api/products/categories"
        );
        setCategories(["ALL", ...categoryResponse.data]);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false); // Set loading state to false after data is fetched (or error occurs)
      }
    };

    fetchData();
  }, []);

  // Debugging Steps:
  console.log("Products fetched:", products); // Log fetched products

  return (
    <ThemeProvider theme={theme}>
      <Router>
        <AppBar />
        <Routes>
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              isLoading ? (
                <p>Loading products...</p>
              ) : (
                <Product products={products} categories={categories} />
              )
            }
          />
          <Route
            path="/product/:id"
            element={<ProductDetails products={products} />}
          />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;