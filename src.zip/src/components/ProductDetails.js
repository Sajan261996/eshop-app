import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './ProductDetails.css';

const ProductDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [product, setProduct] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [orderPlaced, setOrderPlaced] = useState(false); // Track order placement

    useEffect(() => {
        const fetchProductDetails = async () => {
            try {
                const response = await axios.get(
                    `https://dev-project-ecommerce.upgrad.dev/api/products/${id}`
                );
                setProduct(response.data);
            } catch (error) {
                console.error("Error fetching product details:", error);
                alert("Failed to load product details.");
                navigate(-1);
            }
        };

        fetchProductDetails();
    }, [id, navigate]);

    if (!product) {
        return <p>Loading product details...</p>;
    }

    const handleGoBack = () => {
        navigate(-1);
    };

    const handleQuantityChange = (event) => {
        setQuantity(parseInt(event.target.value, 10) || 1);
    };

    const handlePlaceOrder = async () => {
        try {
            const orderData = {
                productId: id,
                quantity: quantity,
            };

            const response = await axios.post(
                "https://dev-project-ecommerce.upgrad.dev/api/orders",
                orderData
            );

            console.log("Order created:", response.data);
            setOrderPlaced(true); // Set orderPlaced to true after successful order
            // Optionally redirect after a short delay
            setTimeout(() => {
                navigate('/orders');
            }, 1500); // Redirect after 1.5 seconds
        } catch (error) {
            console.error("Error placing order:", error);
            alert("Failed to place order. Please try again later.");
        }
    };

    return (
        <div className="product-details-page">
            <div className="product-details-container">
                <button onClick={handleGoBack} className="back-button">Go Back</button>
                <div className="product-details">
                    <div className="product-image">
                        {product.image ? (
                            <img src={product.image} alt={product.name} />
                        ) : (
                            <p>Image not available</p>
                        )}
                    </div>
                    <div className="product-info">
                        <h1>{product.name}</h1>
                        <p>Available Quantity: {product.availableQuantity}</p>
                        <p>Category: {product.category}</p>
                        <p className="product-description">{product.description}</p>
                        <p className="product-price">₹{product.price}</p>

                        <div className="quantity-input">
                            <label htmlFor="quantity">Enter Quantity</label>
                            <input
                                type="number"
                                id="quantity"
                                value={quantity}
                                min="1"
                                onChange={handleQuantityChange}
                            />
                        </div>
                        {orderPlaced ? ( // Conditionally render message or button
                            <p style={{ color: "green" }}>Order placed! Redirecting...</p>
                        ) : (
                            <button className="place-order-button" onClick={handlePlaceOrder}>PLACE ORDER</button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDetails;