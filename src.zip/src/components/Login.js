import React from 'react';
import './Login.css';

const Login = () => {
  return (
    <div className="login-container">
      <div className="login-header">
        <div className="top-bar">
          <div className="logo">upGrad E-Shop</div>
          <div className="auth-links">
            <a href="#">Login</a>
            <a href="#">Sign Up</a>
          </div>
        </div>
      </div>
      <div className="login-form">
        <div className="form-header">
          <span className="lock-icon">🔒</span>
          <h2>Sign in</h2>
        </div>
        <input type="email" placeholder="Email Address *" value="ganeshnaik@gmail.com"/> {/*added value for demonstration*/}
        <input type="password" placeholder="Password *" />
        <button className="login-button">SIGN IN</button>
        <div className="signup-link">
          Don't have an account? <a href="#">Sign Up</a>
        </div>
      </div>
      <div className="footer">
        Copyright © upGrad 2021
      </div>
    </div>
  );
};

export default Login;