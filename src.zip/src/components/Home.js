import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Home = () => {
  const [addresses, setAddresses] = useState([]);
  const [orders, setOrders] = useState([]);

  const fetchAddresses = async () => {
    try {
      const response = await axios.get('https://dev-project-ecommerce.upgrad.dev/api/addresses');
      setAddresses(response.data);
    } catch (error) {
      console.error('Error fetching addresses:', error);
    }
  };

  const fetchOrders = async () => {
    try {
      const response = await axios.get('https://dev-project-ecommerce.upgrad.dev/api/orders');
      setOrders(response.data);
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  useEffect(() => {
    fetchAddresses();
    fetchOrders();
  }, []);

  return (
    <div>
      <h1>Home</h1>

      <section>
        <h2>Addresses</h2>
        <ul>
          {addresses.map((address) => (
            <li key={address.id}>
              {address.name} - {address.city}, {address.state} ({address.zipcode})
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Orders</h2>
        <ul>
          {orders.map((order) => (
            <li key={order.id}>
              Order ID: {order.id} - Quantity: {order.quantity} - Product: {order.product}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default Home;
